# Known gaps

This plant close-out is finance **lite**. Explicitly not in Tamba:

- **No live IRP / NIC e-invoice** — stub IRN + QR only. Cancel window 24h then credit note.
- **No live e-way** to NIC — Form GST EWB-01 print + stub register export.
- **No TDS / TCS** and **no GSTR-2B auto-ITC**.
- **No APS / finite scheduler** — ATP is honest lead-time arithmetic; MRP is weekly netting.
- **No IIoT / MES** — shop books three fields, not machine signals.
- **No deemed-supply interest** — overdue s.143 drafts a tax invoice dated the original challan; it does not compute interest.
- **No multi-company, no customer portal, no HR.**
- **Tally sunset is one-way.** Do not dual-post.

Demo database is **PGLite (Postgres WASM)** in preview. Plant target is **Postgres**. Not SQLite.
