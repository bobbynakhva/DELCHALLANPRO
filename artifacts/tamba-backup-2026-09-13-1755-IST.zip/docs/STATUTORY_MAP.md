# Statutory map — printable PDF → rule / section

| Document | Screen | Law |
|---|---|---|
| Tax invoice | `/print/invoice/$id` | CGST Act s.31, Rule 46 |
| Bill of supply | `/dev/docs/bill-of-supply` | Rule 49 (composition) |
| Job-work delivery challan | `/print/challan/$id` | s.143, Rules 45 + 55 |
| Return challan | `/print/return/$id` | s.143(5) scrap note |
| E-way | `/print/eway/$id` | s.68, Rule 138 Form GST EWB-01 |
| Credit / debit note | `/print/cn/$id` `/print/dn/$id` | s.34, Rule 53 |
| Packing list | `/print/packing/$id` | Commercial; kg must equal invoice |
| GRN / weighment | `/print/grn/$id` | Gross − tare = net |
| Quotation | `/print/quote/$id` | Not a tax invoice; frozen metal rate date |
| Conversion invoice | `/dev/docs/conversion` | SAC 9988 |
| CoC | `/print/coc/$id` | Not a NABL / BIS licence |
| GSTR-1 worksheet | `/gst` | B2B, B2CL, CDNR, HSN Table 12, documents-issued |
| GSTR-3B worksheet | `/gst` | 3.1 outward; ITC from **POSTED** vendor bills only |
| ITC-04 | `/gst` | Tables 4 / 5A / 5B; H1 if turnover > ₹5 Cr else FY |
| Serial integrity | `/gst` | Rule 46 serial; FY gaps in red |

Watermark on worksheets: **Worksheet only. Not a filed return.**
